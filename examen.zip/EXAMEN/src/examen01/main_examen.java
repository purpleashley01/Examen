package examen01;
import java.util.Scanner;
public class main_examen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Scanner teclado=new Scanner(System.in);
		/*Realice un Apps con: 

  1) Ejercicio
  1. Login de  entrada
  2. Menu de opciones:
	a. Ingresar
	b.Registrar 
	c.Realizar tramite
	d. Imprimir factura
	e.Salir*/
		
		String op,ing,reg,nom;
		int fact,trans,contra;
		int camisa,pantalon,zapatos;
		
		
		System.out.println("BIENVENIDO, INGRESE SUS DATOS");
		System.out.println("Ingrese su nombre:");
		nom=teclado.nextLine();
		System.out.println("Ingrese su contraseña:");
		contra=teclado.nextInt();
		
	
	
	System.out.println("Menu de opciones:");
		System.out.println("1.Camisa");
		System.out.println("2.Pantalon");
		System.out.println("3.Zapatos");
		System.out.println("4.Bolso");
		System.out.println("5.Cartera");
			

		System.out.println("Eliga una opcion del 1 al 5:");
		op=teclado.nextLine();
		
		
			 switch (op) {
			 
			 case 1 'camisa $8' 
			break;
			 case 2 'pantalon $10'
			break;
			 case 3 'zapatos $35'
			break;
			 case 4 'Bolso $50'
			 break;
			 case 5 'cartera $30'
			 break;
			 
			 
			 }
			 System.out.println("Se ha ingresado al carrito de cuentas:"+op);
			 
			 
		}
		
	}


